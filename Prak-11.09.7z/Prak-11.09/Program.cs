﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prak_11._09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*------------№1------------*/
            int sum = 0;
            int i = 1;
            while (i <= 10)
            {
                sum += i;
                i++;
            }
            Console.WriteLine(sum);

            /*------------№2------------*/
            int sum1 = 0;
            for (int q = 1; q <= 5; i++)
            {
                sum1 += q;
            }
            Console.WriteLine(sum1);

            /*------------№3------------*/
            for (int w = 1; w <= 10; w++)
            {
                for (int e = 1; e <= 10; e++)
                {
                    Console.Write($"{w} * {e}= {w * e}\t");
                }
            }
            Console.WriteLine();

            /*------------№4------------*/
            int r = 10;
            for (int t = 1; t <= r; t++)
            {
                for (int y = 1; y <= r - t; y++)
                {
                    Console.Write(" ");
                }
                for (int u = 1; u <= t; u++)
                {
                    Console.Write("*");
                }
            }
            Console.WriteLine();

            //
            for (int o = 1; o <= 10; o++)
            {
                if (o == 5)
                { continue; }
                Console.WriteLine(o);
            }

            for (int p = 1; p <= 10; p++)

            {
                if (p == 6)
                { break; }
                Console.WriteLine(p);
            }
        }
    }
}
