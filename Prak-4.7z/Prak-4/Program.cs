﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prak_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*------------№1------------*/
            double a = Convert.ToDouble(Console.ReadLine());
            double s = a * Math.PI;
            double d = Math.Sin(s);
            Console.WriteLine(d);

            /*------------№2------------*/
            double g = Convert.ToDouble(Console.ReadLine());
            double f = Math.Sqrt(g);
            Console.WriteLine(f);

            /*------------№3------------*/
            int h = Convert.ToInt32(Console.ReadLine());
            int j = 1;
            int fac = 1;
            while (j <= h)
            {
                fac *= j;
                j++;
            }
            Console.WriteLine(fac);

            /*------------№4------------*/
            int q = 0;
            int w = 0;
            do
            {
                q = Convert.ToInt32(Console.ReadLine());
                if (q > 0)
                {
                    w += q;
                }
            }
            while (q >= 0);
            Console.WriteLine(w);

            /*------------№5------------*/
            int sum = 0;
            int e = 1;
            while (e <= 100)
            {
                sum += e;
                e++;
            }
            Console.WriteLine(sum);
            Console.ReadKey();

            /*------------№6------------*/
            int r = 0;
            for (r = 0; r <= 20; r++)
            {
                Console.WriteLine(r);
            }
            Console.ReadKey();
        }
    }
}
