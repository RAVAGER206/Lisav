﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NikOrigin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> s = new Queue<string>();
            string input;
            do
            {
                input = Console.ReadLine();
                s.Enqueue(input);
            }
            while (input != "end");
            Queue<string> d = Delite(Console.ReadLine(), s);
            foreach (var item in d)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }

        static Queue<string> Delite(string word, Queue<string> queue)
        {
            Queue<string> temp = new Queue<string>();
            foreach (var item in queue)
            {
                if (item != word)
                {
                    temp.Enqueue(item);
                }
            }
            return temp;
        }
    }
}
