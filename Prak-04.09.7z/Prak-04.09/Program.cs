﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prak_04._09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*------------№1------------*/
            int a = 69;
            Console.WriteLine(a);

            /*------------№2------------*/
            string b;
            b = "Hello, World";
            Console.WriteLine(b);

            /*------------№3------------*/
            const double pi = 3.14;
            Console.WriteLine(pi);

            /*------------№4------------*/
            string name = "Апопий";
            Console.WriteLine(name);

            /*------------№5------------*/
            int age = 119;
            Console.WriteLine(age);

            /*------------№6------------*/
            string messege = $" Привет, {name}! Тебе {age} ";
            Console.WriteLine(messege);

            /*------------№7------------*/
            Console.WriteLine("Введи возраст");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(d);
            Console.ReadKey();
        }
    }
}
