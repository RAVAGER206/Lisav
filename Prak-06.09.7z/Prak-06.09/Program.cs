﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prak_06._09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*------------№1------------*/
            Console.WriteLine("Введите число 1:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите число 2:");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(a + b);

            /*------------№2------------*/
            Console.WriteLine("Введите число 1:");
            int s = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите число 2:");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(s - d);

            /*------------№3------------*/
            Console.WriteLine("Введите угол:");
            int y = Convert.ToInt32(Console.ReadLine());
            double q = Math.Sin(y);
            Console.WriteLine(q);

            /*------------№4------------*/
            Console.WriteLine("Введите число:");
            int e = Convert.ToInt32(Console.ReadLine());
            double t = Math.Sqrt(e);
            Console.WriteLine(t);
            Console.ReadKey();

            /*------------№5------------*/
            Console.WriteLine("Введите число:");
            int r = Convert.ToInt32(Console.ReadLine());
            if (r % 2 == 0) Console.WriteLine("Четное");
            else Console.WriteLine("Нечетное");

            /*------------№6------------*/
            Console.WriteLine("Введите число:");
            int w = Convert.ToInt32(Console.ReadLine());
            if (w > 0) Console.WriteLine("+");
            else if (w < 0) Console.WriteLine("-");
            else Console.WriteLine("0");

            /*------------№7------------*/
            Console.WriteLine("Введите год:");
            int o = Convert.ToInt32(Console.ReadLine());
            if (o % 4 == 0) Console.WriteLine("Високосныйтное");
            else Console.WriteLine("Невисокосный");

            /*------------№8------------*/
            Console.WriteLine("Введите число:");
            int i = Convert.ToInt32(Console.ReadLine());
            if (i < 0) Console.WriteLine("--");
            else if (i < 10) Console.WriteLine("+ но < 10");
            else Console.WriteLine("+");

            /*------------№9------------*/
            Console.WriteLine("Введите число:");
            int k = Convert.ToInt32(Console.ReadLine());
            if (k < 0) Console.WriteLine("--");
            else if (k <= 100) Console.WriteLine("+");
            else Console.WriteLine("-");

            // Release
            int m = 0;
            for (m = 1; m < 11; m++) ;
            Console.WriteLine(m);
            int z = 0;
            for (z = 10; z > 0; z--) ;
            Console.WriteLine(z);
        }
    }
}
